import React from 'react';
import Carousel from 'react-bootstrap/Carousel';

const HomeComponent = () => {
    return (
        <div>
            <h1>Home Page</h1>
            <Carousel>
                <Carousel.Item>
                    <h3>LFP Battery</h3>
                    <p>Rhyno is equipped with Lithium Iron Phosphate (LFP) batteries, renowned for their safety features—eliminating the risk of fire associated with other Lithium batteries. These batteries boast a broader temperature range, ideal for the diverse Indian climate. Our technology enhances Rhyno's longevity, complemented by an Active Balancing Smart Battery Management System (BMS) for extended life and reduced maintenance. Each battery undergoes rigorous waterproofing tests according to IP76 standards. But it doesn't stop there—our technology goes the extra mile in ensuring the battery's lasting durability. Connect with us to discover the thoughtful engineering behind our batteries!</p>
                </Carousel.Item>
            </Carousel>
            <div>
                <img src="vehicle_image_url" alt="Rhyno Vehicle" />
            </div>
        </div>
    );
}

export default HomeComponent;
