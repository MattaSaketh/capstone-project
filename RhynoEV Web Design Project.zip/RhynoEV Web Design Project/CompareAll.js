import React from 'react';

const CompareAllComponent = () => {
    return (
        <div>
            <h1>Compare All</h1>
            <img src="vehicle_image_path_url" alt="Rhyno Vehicle txt" />
            <button type='submit'>Buy Now</button>
            <table>
                <thead>
                    <tr>
                        <th>Specification</th>
                        <th>Rhyno SE03 Lite</th>
                        <th>Rhyno SE03</th>
                        <th>Rhyno SE03 Max</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Battery</td>
                        <td>1.8Kwh</td>
                        <td>2.7Kwh</td>
                        <td>2.7Kwh</td>
                    </tr>
                </tbody>
            </table>
        </div>
    );
}

export default CompareAllComponent;
