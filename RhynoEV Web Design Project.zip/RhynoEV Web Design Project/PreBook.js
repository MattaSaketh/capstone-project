import React from 'react';

const PreBookComponent = () => {
    return (
        <div>
            <h1>Pre-book Now</h1>
        </div>
    );
}

export default PreBookComponent;
